#include <stdio.h>
#include <stdlib.h>

int main(int arcg, char** argv) {
	return EXIT_SUCCESS;
} 
